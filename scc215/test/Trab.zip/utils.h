#ifndef _UTILS_H_
#define _UTILS_H_

void binarioNaTela(char*);
void trim(char*);
void scan_quote_string(char*);
char* split(char*);

#endif